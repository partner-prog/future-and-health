# Future & Health Institute

Website for the Future & Health Institute — AI Strategy for Healthcare Leaders.

Built by Dr. Ashish Atreja. Deployed via Vercel.
